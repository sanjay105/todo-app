# -*- coding: utf-8 -*-
from __future__ import unicode_literals


from django.shortcuts import render

# Create your views here.
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, DetailView

from todo.models import Todolist, Todoitem


class TodoListView(ListView):
    model=Todolist
    context_object_name ='tlists'

class TodoListCreateView(CreateView):
    model=Todolist
    fields = ['name','creation_date']

class TodoView(DetailView):
    model=Todolist
    context_object_name = 'todoli'
    template_name = "todo/litem_list_id.html"

    def get_context_data(self, **kwargs):
        context = super(TodoView, self).get_context_data(**kwargs)
        context['itlists'] = Todoitem.objects.all().filter(todolist=self.object)
        return context

class TodoListUpdateView(UpdateView):
    model=Todolist
    fields = ['name', 'creation_date']

class TodoListDeleteView(DeleteView):
    model=Todolist
    success_url = reverse_lazy('todo:todolist')

class TodoItemView(ListView):
    model=Todoitem
    context_object_name ='tlists'

class TodoItemCreateView(CreateView):
    model=Todoitem
    fields = ['description','completed','due_by','todolist']

class TodoItemUpdateView(UpdateView):
    model=Todoitem
    fields = ['description','completed','due_by','todolist']

class TodoItemDeleteView(DeleteView):
    model=Todoitem
    success_url = reverse_lazy('todo:todoitem')